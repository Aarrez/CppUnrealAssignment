﻿#include "CoolControlPoints.h"
#include "AssetRegistry/AssetRegistryModule.h"


ACoolControlPoints::ACoolControlPoints()
{
	
}

void ACoolControlPoints::BeginPlay()
{
	Super::BeginPlay();
}

